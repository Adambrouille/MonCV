from math import sqrt
#RESOLVEUR D'EQUATION DU SECOND DEGREES

a = int(input("coef de x**2 : "))
b = int(input("coef de x : "))
c = int(input("coef du terme indep : "))
#calcul de delta
d = (b**2)-4*a*c
print("Delta =", d)
#calcul des racines
if d == 0:
    x = -b/2*a
    print("la racine double est", x)
    print("le polynome peut s'écrire (",int(sqrt(a)),"x +",int(sqrt(c)),")**2")
elif d > 0:
    x_1 = float((-b + sqrt(d))/2*a)
    x_2 = float((-b - sqrt(d))/2*a)
    print("les racines sont", x_1, "et", x_2)
else:
    print("aucune racine réel")
#concavité
if a > 0:
    print("la parabole est convexe")
else:
    print("la parabole est concave")
#f(0)
print("f(0)=",c)
#coordonnées du sommet
print("les cc du somment sont","(",-b/(2*a),",",-d/(4*a),")")
#calcul de la dérivé
print("la dérivée 1ère est", 2*a,"x +", b)
print("la dérivée seconde est", 2*a)
#calcul de la primitive
print("la primitive est", 1/3*a,"x**3 +", 1/2*b,"x**2 +",c,"x + cst")

